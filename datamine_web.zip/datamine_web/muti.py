from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import roc_curve, auc, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
import argparse

x_classification = pd.read_csv('sever/mock/class.csv')
x_regression = pd.read_csv('sever/mock/regression.csv')
Total_file = "sever/mock/data.json"


# 将json文件转为df文件
def json_to_csv(json_file):
    # df = pd.DataFrame(json_file)
    df = pd.read_json(json_file, encoding="utf-8", orient='records')
    return df


# 分数据集
def split_train_test(file):
    df = json_to_csv(file)
    train_file, test_file = train_test_split(df, test_size=0.2)
    return train_file, test_file


train_df, test_df = split_train_test(Total_file)


# 分开标签和特征
def split_data(df: pd.DataFrame, mode: str):
    if mode == "regression":
        y = df['life_expectancy']
        x = df.drop(columns=['life_expectancy'])
        print("当前是回归问题")
    else:
        y = df['economy_status_developed']
        x = df.drop(columns=['economy_status_developed'])
        print("当前是分类问题")
        print(y)
        print(x)
    return x, y


# 朴素贝叶斯
def naive_bayes(x_train, y_train):
    model = GaussianNB()
    model.fit(x_train, y_train)
    return model


# 决策树
def decision_tree(x_train, y_train):
    model = DecisionTreeClassifier(random_state=42)
    model.fit(x_train, y_train)
    return model


# 随机森林
def random_forest(x_train, y_train):
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(x_train, y_train)
    return model


# SVM,使用线性核
def svm(x_train, y_train):
    model = SVC(kernel='linear', random_state=42)
    model.fit(x_train, y_train)
    return model


# 逻辑回归
def logistic_regression(x_train, y_train):
    model = LogisticRegression(max_iter=1000)
    model.fit(x_train, y_train)
    return model


# 决策提升树
def gradient_boosting_trees(x_train, y_train):
    model = GradientBoostingClassifier(n_estimators=100, random_state=42)
    model.fit(x_train, y_train)
    return model


# 线性回归
def linear_regression(x_train, y_train):
    model = LinearRegression()
    model.fit(x_train, y_train)
    return model


# 残差图
def draw_residuals(x, y, title: str):
    plt.figure(figsize=(8, 8))
    sns.scatterplot(x=x, y=y, color='green', alpha=0.6)
    plt.axhline(y=0, color='red', linestyle='--', linewidth=2)
    plt.title(title)
    plt.tight_layout()
    plt.show()


# ROC曲线
def draw_roc(x, y, title: str, auc: int):
    # 绘制ROC曲线
    plt.figure(figsize=(8, 8))
    plt.plot(x, y, color='darkorange', lw=2, label=f'AUC = {auc:.2f}')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title(f'ROC {title}')
    plt.legend(loc='lower right')
    plt.show()


# 构建字典，以方便后续模型的选择
model_dir = {
    'random_forest': random_forest,
    'naive_bayes': naive_bayes,
    'gradient_boosting_trees': gradient_boosting_trees,
    'logistic_regression': logistic_regression,
    'decision_tree': decision_tree,
    'svm': svm
}


class ModelFactory:
    def __init__(self, mode: str):
        self.r2 = None
        self.mse = None
        self.mode = mode

        self.model_name = 'linear_regression'

        self.model = None
        self.y_pred = None
        self.y_test = None
        self.x_test = None
        self.y_train = None
        self.x_train = None
        self.roc_auc = None
        self.fpr = None
        self.tpr = None

    # 数据预处理
    def data_pre(self):
        self.x_train, self.y_train = split_data(train_df, self.mode)
        self.x_test, self.y_test = split_data(test_df, self.mode)

    # 选择模型
    def model_choice(self, model_type: str):
        if self.mode == 'regression':
            self.model = linear_regression(self.x_train, self.y_train)
        else:
            self.model = model_dir[model_type]
            self.model = self.model(self.x_train, self.y_train)
            self.model_name = model_type

    def predict(self):
        self.model.fit(self.x_train, self.y_train)
        self.y_pred = self.model.predict(self.x_test)
        return self.y_pred

    # 预测
    def predict_val(self, x_valid):
        self.model.fit(self.x_train, self.y_train)
        self.y_pred = self.model.predict(x_valid)
        return self.y_pred

    # 模型的评估
    def evaluate(self):
        self.predict()
        if self.mode == 'regression':
            self.mse = np.mean((self.y_test - self.y_pred) ** 2)
            self.r2 = self.model.score(self.x_test, self.y_test)
            print(f"Mean Squared Error (MSE): {self.mse:.2f}")
            print(f"R-squared (R2): {self.r2:.2f}")
        else:
            # 计算混淆矩阵
            conf_matrix = confusion_matrix(self.y_test, self.y_pred)
            # 计算 ROC 曲线
            self.fpr, self.tpr, thresholds = roc_curve(self.y_test, self.model.predict_proba(self.x_test)[:, 1])
            # 计算AUC，准确度，精确度，召回率，F1值
            self.roc_auc = auc(self.fpr, self.tpr)
            accuracy = metrics.accuracy_score(self.y_test, self.y_pred)
            precision = metrics.precision_score(self.y_test, self.y_pred)
            recall = metrics.recall_score(self.y_test, self.y_pred)
            f1_score = metrics.f1_score(self.y_test, self.y_pred)
            print(f"Confusion Matrix:\n{conf_matrix}")
            print(f"Accuracy: {accuracy:.4f}")
            print(f"Precision: {precision:.4f}")
            print(f"Recall: {recall:.4f}")
            print(f"F1 Score: {f1_score:.4f}")
            print(f"AUC: {self.roc_auc:.4f}\n")

    def draw(self):
        if self.mode == 'regression':
            # 绘制残差图
            residuals = self.y_test - self.y_pred
            draw_residuals(self.y_test, residuals, 'Residuals Plot')
        else:
            # 绘制ROC曲线
            draw_roc(self.fpr, self.tpr, f'ROC {self.model_name}', self.roc_auc)


def main(task='regression', model='naive_bayes'):
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['classification', 'regression'], default=fr'{task}', type=str,
                        required=False, help='选一个任务模式，分类任务还是回归任务，默认是回归任务')
    parser.add_argument('--model',
                        choices=['naive_bayes', 'decision_tree', 'random_forest', 'svm', 'logistic_regression',
                                 'gradient_boosting_trees'], nargs='+', default=fr'{model}', required=False,
                        help='分类模型选择')

    args = parser.parse_args()

    # 模型初始化
    model = ModelFactory(args.mode)
    model.data_pre()

    if args.mode == 'regression':
        model.model_choice(args.model)
        model.evaluate()
        model.draw()
    else:
        for i in range(0, len(args.model)):
            print(args.model[i])

            model.model_choice(args.model[i])
            model.evaluate()
            model.draw()

    if args.mode == 'regression':
        predict = model.predict_val(x_regression)
    else:
        predict = model.predict_val(x_classification)
    print(predict)
    print(model.mse)
    print(model.r2)
    return predict, model.mse, model.r2


if __name__ == '__main__':
    main('regression')
