let express=require("express");
let router=express.Router()

router.get("/data", (req, res)=>{
    res.send({msg:"我是four的路由地址"})
})

module.exports=router;