from django.shortcuts import render
from .models import DataBase, Life2015, Class, Regression
from .serializers import DataBaseSerializer, LifeSerializer, ClassSerializer, RegressionSerializer
from rest_framework import viewsets, mixins
from django.db.models import Count
from rest_framework.decorators import api_view
from rest_framework.generics import get_object_or_404
from rest_framework.response import Response
from rest_framework import status
import muti


# Create your views here.
class DataBaseViews(viewsets.ModelViewSet):
    serializer_class = DataBaseSerializer

    def get_queryset(self):
        return DataBase.objects.all()


class Life2015Views(viewsets.ModelViewSet):
    serializer_class = LifeSerializer

    def get_queryset(self):
        health_expect = Life2015.objects.all()
        return health_expect


class ClassViews(viewsets.ModelViewSet):
    serializer_class = ClassSerializer

    def get_queryset(self):
        return Class.objects.all()


class RegressionViews(viewsets.ModelViewSet):
    serializer_class = RegressionSerializer

    def get_queryset(self):
        return Regression.objects.all()


@api_view(['POST'])
def get_test(request):
    test_data = request.data.get('testData')
    task = request.data.get('task')
    test_id = request.data.get('id')
    if not test_data:
        return Response({'error': '测试数据传输出错。'}, status=status.HTTP_400_BAD_REQUEST)
    answer, mse, r2 = muti.main(task)
    answer = answer[test_id]
    return Response({'predict': answer, 'mse': mse, 'r2': r2})
