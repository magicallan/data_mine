from rest_framework import serializers
from .models import DataBase, Life2015, Regression, Class


class DataBaseSerializer(serializers.ModelSerializer):
    class Meta:
        model = DataBase
        fields = ['infant_deaths', 'under_five_deaths', 'adult_mortality', 'alcohol_consumption', 'hepatitis_b',
                  'measles', 'bmi', 'polio', 'diphtheria', 'incidents_hiv', 'gdp_per_capita', 'population_mln',
                  'thinness_ten_nineteen_years', 'thinness_five_nine_years', 'schooling', 'economy_status_developed', 'life_expectancy']


class LifeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Life2015
        fields = ['country', 'expect_life']


class RegressionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Regression
        fields = ['infant_deaths', 'under_five_deaths', 'adult_mortality', 'alcohol_consumption', 'hepatitis_b',
                  'measles', 'bmi', 'polio', 'diphtheria', 'incidents_hiv', 'gdp_per_capita', 'population_mln',
                  'thinness_ten_nineteen_years', 'thinness_five_nine_years', 'schooling', 'economy_status_developed']


class ClassSerializer(serializers.ModelSerializer):
    class Meta:
        model = Class
        fields = ['infant_deaths', 'under_five_deaths', 'adult_mortality', 'alcohol_consumption', 'hepatitis_b',
                  'measles', 'bmi', 'polio', 'diphtheria', 'incidents_hiv', 'gdp_per_capita', 'population_mln',
                  'thinness_ten_nineteen_years', 'thinness_five_nine_years', 'schooling', 'life_expectancy']
