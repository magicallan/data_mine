from django.db import models


# Create your models here.


class DataBase(models.Model):
    country = models.TextField(db_column='Country', blank=True, null=True)  # Field name made lowercase.
    year = models.IntegerField(db_column='Year', blank=True, null=True)  # Field name made lowercase.
    infant_deaths = models.FloatField(db_column='Infant_deaths', blank=True, null=True)  # Field name made lowercase.
    under_five_deaths = models.FloatField(db_column='Under_five_deaths', blank=True,
                                          null=True)  # Field name made lowercase.
    adult_mortality = models.FloatField(db_column='Adult_mortality', blank=True,
                                        null=True)  # Field name made lowercase.
    alcohol_consumption = models.FloatField(db_column='Alcohol_consumption', blank=True,
                                            null=True)  # Field name made lowercase.
    hepatitis_b = models.IntegerField(db_column='Hepatitis_B', blank=True, null=True)  # Field name made lowercase.
    measles = models.IntegerField(db_column='Measles', blank=True, null=True)  # Field name made lowercase.
    bmi = models.FloatField(db_column='BMI', blank=True, null=True)  # Field name made lowercase.
    polio = models.IntegerField(db_column='Polio', blank=True, null=True)  # Field name made lowercase.
    diphtheria = models.IntegerField(db_column='Diphtheria', blank=True, null=True)  # Field name made lowercase.
    incidents_hiv = models.FloatField(db_column='Incidents_HIV', blank=True, null=True)  # Field name made lowercase.
    gdp_per_capita = models.IntegerField(db_column='GDP_per_capita', blank=True,
                                         null=True)  # Field name made lowercase.
    population_mln = models.FloatField(db_column='Population_mln', blank=True, null=True)  # Field name made lowercase.
    thinness_ten_nineteen_years = models.FloatField(db_column='Thinness_ten_nineteen_years', blank=True,
                                                    null=True)  # Field name made lowercase.
    thinness_five_nine_years = models.FloatField(db_column='Thinness_five_nine_years', blank=True,
                                                 null=True)  # Field name made lowercase.
    schooling = models.FloatField(db_column='Schooling', blank=True, null=True)  # Field name made lowercase.
    economy_status_developed = models.IntegerField(db_column='Economy_status_Developed', blank=True,
                                                   null=True)  # Field name made lowercase.
    life_expectancy = models.FloatField(db_column='Life_expectancy', blank=True,
                                        null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'data_base'


class Life2015(models.Model):
    country = models.TextField(blank=True, null=True)
    expect_life = models.FloatField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'life_2015'


class Class(models.Model):
    infant_deaths = models.FloatField(db_column='Infant_deaths', blank=True, null=True)  # Field name made lowercase.
    under_five_deaths = models.FloatField(db_column='Under_five_deaths', blank=True,
                                          null=True)  # Field name made lowercase.
    adult_mortality = models.FloatField(db_column='Adult_mortality', blank=True,
                                        null=True)  # Field name made lowercase.
    alcohol_consumption = models.FloatField(db_column='Alcohol_consumption', blank=True,
                                            null=True)  # Field name made lowercase.
    hepatitis_b = models.FloatField(db_column='Hepatitis_B', blank=True, null=True)  # Field name made lowercase.
    measles = models.FloatField(db_column='Measles', blank=True, null=True)  # Field name made lowercase.
    bmi = models.FloatField(db_column='BMI', blank=True, null=True)  # Field name made lowercase.
    polio = models.FloatField(db_column='Polio', blank=True, null=True)  # Field name made lowercase.
    diphtheria = models.FloatField(db_column='Diphtheria', blank=True, null=True)  # Field name made lowercase.
    incidents_hiv = models.FloatField(db_column='Incidents_HIV', blank=True, null=True)  # Field name made lowercase.
    gdp_per_capita = models.FloatField(db_column='GDP_per_capita', blank=True, null=True)  # Field name made lowercase.
    population_mln = models.FloatField(db_column='Population_mln', blank=True, null=True)  # Field name made lowercase.
    thinness_ten_nineteen_years = models.FloatField(db_column='Thinness_ten_nineteen_years', blank=True,
                                                    null=True)  # Field name made lowercase.
    thinness_five_nine_years = models.FloatField(db_column='Thinness_five_nine_years', blank=True,
                                                 null=True)  # Field name made lowercase.
    schooling = models.FloatField(db_column='Schooling', blank=True, null=True)  # Field name made lowercase.
    life_expectancy = models.FloatField(db_column='Life_expectancy', blank=True,
                                        null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'class'


class Regression(models.Model):
    infant_deaths = models.FloatField(db_column='Infant_deaths', blank=True, null=True)  # Field name made lowercase.
    under_five_deaths = models.FloatField(db_column='Under_five_deaths', blank=True,
                                          null=True)  # Field name made lowercase.
    adult_mortality = models.FloatField(db_column='Adult_mortality', blank=True,
                                        null=True)  # Field name made lowercase.
    alcohol_consumption = models.FloatField(db_column='Alcohol_consumption', blank=True,
                                            null=True)  # Field name made lowercase.
    hepatitis_b = models.FloatField(db_column='Hepatitis_B', blank=True, null=True)  # Field name made lowercase.
    measles = models.FloatField(db_column='Measles', blank=True, null=True)  # Field name made lowercase.
    bmi = models.FloatField(db_column='BMI', blank=True, null=True)  # Field name made lowercase.
    polio = models.FloatField(db_column='Polio', blank=True, null=True)  # Field name made lowercase.
    diphtheria = models.FloatField(db_column='Diphtheria', blank=True, null=True)  # Field name made lowercase.
    incidents_hiv = models.FloatField(db_column='Incidents_HIV', blank=True, null=True)  # Field name made lowercase.
    gdp_per_capita = models.FloatField(db_column='GDP_per_capita', blank=True, null=True)  # Field name made lowercase.
    population_mln = models.FloatField(db_column='Population_mln', blank=True, null=True)  # Field name made lowercase.
    thinness_ten_nineteen_years = models.FloatField(db_column='Thinness_ten_nineteen_years', blank=True,
                                                    null=True)  # Field name made lowercase.
    thinness_five_nine_years = models.FloatField(db_column='Thinness_five_nine_years', blank=True,
                                                 null=True)  # Field name made lowercase.
    schooling = models.FloatField(db_column='Schooling', blank=True, null=True)  # Field name made lowercase.
    economy_status_developed = models.IntegerField(db_column='Economy_status_Developed', blank=True,
                                                   null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'regression'

