from django.contrib import admin
from .models import DataBase, Life2015


# Register your models here.

class DataBaseAdmin(admin.ModelAdmin):
    list_display = ['country', 'year', 'life_expectancy']


class Life2015Admin(admin.ModelAdmin):
    list_display = ['country', 'expect_life']


admin.site.register(DataBase, DataBaseAdmin)
admin.site.register(Life2015, Life2015Admin)