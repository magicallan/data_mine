import csv
with open('AVG_load2.csv', 'a', encoding='utf-8') as g:
    with open('AVG.csv', 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        for line in reader:
            # bar = '{name: \'' + line[0] + '\'' + ',' + ' value: ' + line[1] + ' },' + '\n'
            bar = '{\'value\': ' + line[1] + ' },' + ' '
            g.write(bar)


